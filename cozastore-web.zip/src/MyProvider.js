import MyContext from "./MyContext";
import React, { Component } from "react";

class MyProvider extends Component {
  state = {
    shoppingCart: [{ name: "tung" }],
  };
  render() {
    return (
      <MyContext.Provider value={{ shoppingCart: this.state.shoppingCart }}>
        {this.props.children}
      </MyContext.Provider>
    );
  }
}

export default MyProvider;
