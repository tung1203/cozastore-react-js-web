import React, { Component } from 'react'

export default class useSlide extends Component {
    componentDidMount()
    render() {
        return (
            <div>
                
            </div>
        )
    }
}
